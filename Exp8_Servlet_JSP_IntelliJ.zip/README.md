# Experiment 8 - Web Applications Using Servlets and JSP (IntelliJ Maven project)

## What is included
- Maven-based web application (WAR packaging)
- JSP form (`index.jsp`) to collect student name and email
- `RegisterServlet` to insert submitted data into MySQL `studentdb.students`
- `web.xml` servlet mapping
- Instructions to build and run with Tomcat and IntelliJ IDEA

## MySQL credentials (provided by you)
- Username: aman
- Password: 12345
- Database: studentdb
- Table: students (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50), email VARCHAR(50))

**Important:** For security, change the password or use environment variables in production.

## How to run
1. Import this project into IntelliJ as a Maven project.
2. Build -> Run 'mvn package' to produce the WAR in `target/`.
3. Deploy the generated WAR to Apache Tomcat (or configure Tomcat in IntelliJ Run Configurations).
4. Make sure MySQL is running and database `studentdb` and table `students` exist (see `sql/create_db.sql`).
5. Add MySQL Connector/J (JDBC driver) to Tomcat's `lib/` folder or to the project's runtime classpath.

## Files of note
- `src/main/webapp/index.jsp` — user input form
- `src/main/java/com/example/servlets/RegisterServlet.java` — servlet that inserts into DB
- `src/main/webapp/WEB-INF/web.xml` — servlet mapping
- `sql/create_db.sql` — SQL to create database and table
